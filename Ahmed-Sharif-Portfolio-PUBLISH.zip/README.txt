AHMED SHARIF PORTFOLIO — PUBLISH-READY

This folder is ready for static hosting. The website is completely self-contained in index.html.

GitHub Pages:
1. Create a GitHub repository named YOUR-USERNAME.github.io
2. Upload index.html to the repository root
3. Commit the file
4. Open Settings > Pages
5. Under Build and deployment, choose Deploy from a branch
6. Select main and /(root), then Save
7. Your site will be available at https://YOUR-USERNAME.github.io

For a custom domain later, add it in Settings > Pages > Custom domain after buying a domain.
